class EUHomepage < EssoBase

  def visit
    visit_page("/")
  end





  private






end
