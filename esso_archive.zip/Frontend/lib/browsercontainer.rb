class BrowserContainer

  def initialize(browser)
    @browser = browser
  end

  def visit_page(page_url = "")
    @browser.goto ENV['HOST'] + page_url
  end



end
