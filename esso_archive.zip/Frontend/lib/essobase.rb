class EssoBase < BrowserContainer

  def eu_homepage
    EUHomepage.new(@browser)
  end

  def eu_stations
    Stations.new(@browser)
  end

















end
