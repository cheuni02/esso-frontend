When /^i visit the Esso page for the first time$/ do
  site.eu_homepage.visit  
end
