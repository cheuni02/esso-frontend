require 'watir-webdriver'
require 'cucumber'
require 'require_all'
require 'fileutils'

require_all 'lib'

FileUtils.mkdir_p "Screenshots"
Watir.default_timeout = 15


case ENV['BROWSER'].to_sym
when :chrome
  browser = Watir::Browser.new :chrome
when :ie
  browser = Watir::Browser.new :ie
else
  profile = Selenium::WebDriver::Firefox::Profile.new
  profile['browser.cache.disk.enable'] = false
  profile['browser.cache.disk.capacity'] = 0
  profile['network.http.pipelining'] = true
  profile['network.http.proxy.pipelining'] = true
  profile['network.http.pipelining.maxrequests'] = 8

  # Set to allow Geolocation Tests
  profile['geo.prompt.testing'] = true
  profile['geo.prompt.testing.allow'] = true
  browser = Watir::Browser.new :firefox, :profile => profile
end


browser.window.maximize

class CustomWorld
  class << self; attr_accessor :browser end
  #attr_accessor :browser

  def site
    @site ||= (EssoBase.new(CustomWorld::browser))
  end

end

CustomWorld.browser = browser

World do
  CustomWorld.new
  #STDOUT.puts CustomWorld.browser
end


After do |scenario|
  if scenario.failed? # Screenshot if scenario fails
    time = Time.now.strftime("%Y-%m-%d-%H%M%S")
    name = "#{time}-#{scenario.name}".slice(0, 250).gsub(/[\,\/]/, '-')
    name.gsub!(/[\|\s]/, '')
    file_dir = "#{screenshot_dir}/#{name}.png"
    browser.screenshot.save file_dir
    embed(file_dir, "image/png" "SCREENSHOT")
  end
end
